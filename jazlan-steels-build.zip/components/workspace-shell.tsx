'use client'

import { useState, type ReactNode } from 'react'
import { Bell, LogOut, Menu, X } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

export type WorkspaceNavItem = { label: string; href: string; icon: LucideIcon; count?: number }
export type WorkspaceUser = { name: string; role: string; initials: string }
export type WorkspaceShellProps = { workspace: 'Accounting' | 'Billing'; navItems: WorkspaceNavItem[]; user: WorkspaceUser; breadcrumb: string; title: string; subtitle?: string; periodSlot?: ReactNode; children: ReactNode; legacy?: boolean }

export function WorkspaceShell({ workspace, navItems, user, breadcrumb, title, subtitle, periodSlot, children, legacy = false }: WorkspaceShellProps) {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [profileOpen, setProfileOpen] = useState(false)
  const signOut = () => { localStorage.removeItem('jazlan-session'); window.location.assign('/login') }
  if (legacy) return <>{children}</>
  return <div className="workspace-shell"><aside className={`workspace-sidebar ${mobileOpen ? 'open' : ''}`}><div className="workspace-brand"><div className="workspace-logo">JZ</div><div><b>JAZLAN</b><span>STEELS</span></div><button className="workspace-close" onClick={() => setMobileOpen(false)} aria-label="Close navigation"><X /></button></div><div className="workspace-divider"/><div className="workspace-context"><span>{workspace.toUpperCase()} WORKSPACE</span></div><div className="workspace-divider"/><nav className="workspace-nav">{navItems.map(({ label, href, icon: Icon, count }) => <a href={href} key={label}><Icon /><span>{label}</span>{count !== undefined && <b>{count}</b>}</a>)}</nav><div className="workspace-sidebar-bottom"><div className="workspace-divider"/><div className="workspace-user"><div className="workspace-avatar">{user.initials}</div><div><b>{user.name}</b><span>{user.role}</span></div></div><button className="workspace-signout" onClick={signOut}><LogOut />Sign out</button></div></aside>{mobileOpen && <button className="workspace-scrim" onClick={() => setMobileOpen(false)} aria-label="Close navigation"/>}<div className="workspace-main"><header className="workspace-topbar"><button className="workspace-menu" onClick={() => setMobileOpen(true)} aria-label="Open navigation"><Menu /></button><div><span>{breadcrumb}</span><h1>{title}</h1>{subtitle && <p className="workspace-subtitle">{subtitle}</p>}</div><div className="workspace-top-actions">{periodSlot}<Bell /><div className="workspace-profile-wrap"><button className="workspace-top-avatar" onClick={() => setProfileOpen((open) => !open)} aria-label="Open profile">{user.initials}</button>{profileOpen && <div className="workspace-profile-menu"><b>{user.name}</b><span>{user.role}</span><hr/><button onClick={signOut}><LogOut />Sign out</button></div>}</div></div></header><main className="workspace-content">{children}<footer className="workspace-footer"><span>JAZLAN STEELS · {workspace} workspace</span><span><i/>Reference date 31/05/2026</span></footer></main></div></div>
}
