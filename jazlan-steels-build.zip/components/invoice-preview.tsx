'use client'

import { COMPANY } from '@/lib/config'
import { numberToWordsINR } from '@/lib/calculations'
import type { GeneratedBill } from '@/lib/billing'

const money = (value: number) => new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value)

export function InvoicePreview({ invoice }: { invoice: GeneratedBill }) {
  const taxable = invoice.subtotal
  const quantity = invoice.quantity ?? 1
  const items = invoice.items ?? [{ material: 'Steel supply', hsn: '7208', quantity, rate: invoice.subtotal / quantity }]
  return <article className="invoice-preview">
    {invoice.status === 'Cancelled' && <div className="cancelled-watermark">CANCELLED</div>}
    <div className="invoice-title">TAX INVOICE</div>
    <header className="invoice-header"><div className="invoice-logo">JS</div><div className="invoice-company"><strong>{COMPANY.name}</strong><span>{COMPANY.address}</span><span>GSTIN: {COMPANY.gstin} || EMAIL: traderssmt3@gmail.com</span></div></header>
    <div className="invoice-meta"><div><span>Inv No: <b>{invoice.invoiceNo}</b></span><span>Inv Date: <b>{invoice.invoiceDate}</b></span><span>PO No: <b>—</b></span></div><div><span>Date of Supply: <b>{invoice.invoiceDate}</b></span><span>Vehicle No: <b>{invoice.vehicle}</b></span><span>E Way Bill No: <b>—</b></span></div></div>
    <div className="invoice-address"><div><b>Billing Address</b><span>{invoice.customer}</span><span>{invoice.address}</span><span>GSTIN: {invoice.gstin}</span></div><div><b>Shipping Address</b><span>{invoice.customer}</span><span>{invoice.address}</span><span>GSTIN: {invoice.gstin}</span></div></div>
    <table className="invoice-table"><thead><tr><th>NO</th><th>Product Description</th><th>HSN Code</th><th>QTY</th><th>Unit</th><th>Rate</th><th>Amount</th></tr></thead><tbody>{items.map((item,index)=><tr key={`${item.material}-${index}`}><td>{index+1}</td><td>{item.material}</td><td>{item.hsn}</td><td>{item.quantity.toLocaleString('en-IN')}</td><td>KGS</td><td>{money(item.rate)}</td><td>{money(item.quantity*item.rate)}</td></tr>)}<tr><td colSpan={3}><b>Total Qty</b></td><td><b>{quantity.toLocaleString('en-IN')}</b></td><td colSpan={3}></td></tr></tbody></table>
    <div className="invoice-totals"><div className="invoice-words"><b>Total Invoice Amount in words</b><span>INR {numberToWordsINR(invoice.grandTotal)} Only</span></div><div><span>Sub Total <b>{money(invoice.subtotal)}</b></span><span>CGST @ 9% <b>{money(invoice.cgst)}</b></span><span>SGST @ 9% <b>{money(invoice.sgst)}</b></span><span>Roundoff <b>{invoice.roundOff >= 0 ? '+' : ''}{money(invoice.roundOff)}</b></span><strong>Grand Total <b>{money(invoice.grandTotal)}</b></strong><span>Less: TDS @ 2% <b>{money(invoice.tds)}</b></span><strong>Net Amount Payable <b>{money(invoice.netPayable)}</b></strong></div></div>
    <div className="invoice-bank"><b>Bank Details</b><span>Account Name: JAZLAN STEELS</span><span>Branch Name: MOGAPPAIR WEST, CH-37.</span><span>Bank Name: HDFC BANK</span><span>Account Number: 50200066429387</span><span>IFSC Code: HDFC0001765</span></div>
    <table className="invoice-table invoice-hsn"><thead><tr><th>HSN Code</th><th>Taxable Amt</th><th>CGST % / Amt</th><th>SGST % / Amt</th><th>Grand Total</th></tr></thead><tbody><tr><td>{items[0]?.hsn || '7204'}</td><td>{money(taxable)}</td><td>9% / {money(invoice.cgst)}</td><td>9% / {money(invoice.sgst)}</td><td>{money(invoice.grandTotal)}</td></tr></tbody></table>
    <footer className="invoice-footer"><div><b>Declaration</b><ol><li>Goods once sold will not be taken back or exchanged.</li><li>Seller is not responsible for any loss or damage of goods in transit.</li><li>Buyer undertakes to submit prescribed ST declaration to sender on demand.</li><li>Disputes subject to seller court jurisdiction.</li></ol></div><div className="signature"><b>For M/s. JAZLAN STEELS</b><span>Authorised Signatory</span></div></footer>
  </article>
}
