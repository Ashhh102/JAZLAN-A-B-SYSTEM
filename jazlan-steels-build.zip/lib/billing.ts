export const BILLING_KEY = 'jazlan-bills'
export const BILL_COUNTER_KEY = 'jazlan-invoice-counter'
export const TRIP_COUNTER_KEY = 'jazlan-trip-counter'

export const materials = ['MS BORING','ROD BIT','MELDING','ROLLING','GM MELDING','MS SCRAP','CAST IRON','HMS 1&2','TURNING','CRCA','COPPER SCRAP']

export type BillItem = { material:string; quantity:number; rate:number; hsn:string }
export type GeneratedBill = { invoiceNo:string; invoiceDate:string; vehicle:string; customer:string; address:string; gstin:string; items:BillItem[]; subtotal:number; cgst:number; sgst:number; roundOff:number; grandTotal:number; tds:number; netPayable:number; status:'Pending'|'Cancelled'; locked:boolean; tripId:string }

export const nextInvoiceNo = () => {
  const next = typeof window === 'undefined' ? 75 : Number(window.localStorage.getItem(BILL_COUNTER_KEY) || '75')
  return `SMT/26-27/${String(next).padStart(3, '0')}`
}
export const nextTripId = () => {
  const next = typeof window === 'undefined' ? 1025 : Number(window.localStorage.getItem(TRIP_COUNTER_KEY) || '1025')
  return `TR-${next}`
}
export const saveGeneratedBill = (bill:GeneratedBill) => {
  const bills:GeneratedBill[] = JSON.parse(window.localStorage.getItem(BILLING_KEY) || '[]')
  window.localStorage.setItem(BILLING_KEY, JSON.stringify([...bills, bill]))
  window.localStorage.setItem(BILL_COUNTER_KEY, String(Number(window.localStorage.getItem(BILL_COUNTER_KEY) || '75') + 1))
  window.localStorage.setItem(TRIP_COUNTER_KEY, String(Number(window.localStorage.getItem(TRIP_COUNTER_KEY) || '1025') + 1))
}
