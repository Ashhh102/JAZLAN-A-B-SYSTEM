import type { UserRole } from './auth'

export type Capability =
  | 'accounting.view'
  | 'accounting.edit'
  | 'bills.view'
  | 'bills.print'
  | 'billing.view'
  | 'bills.create'
  | 'bills.cancel'

export const CAPABILITIES: Record<UserRole, readonly Capability[]> = {
  accounting: ['accounting.view', 'accounting.edit', 'bills.view', 'bills.print'],
  billing: ['billing.view', 'bills.create', 'bills.view', 'bills.print', 'bills.cancel'],
}

export function can(role: UserRole | null | undefined, capability: Capability) {
  return Boolean(role && CAPABILITIES[role]?.includes(capability))
}

export function canAccessRoute(role: UserRole | null | undefined, pathname: string) {
  if (!role) return false
  if (pathname === '/accounting' || pathname.startsWith('/accounting/')) return role === 'accounting'
  if (pathname === '/billing' || pathname.startsWith('/billing/')) return role === 'billing'
  return true
}
