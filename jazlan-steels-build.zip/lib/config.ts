export const REFERENCE_DATE = '2026-05-31'
export const COMPANY = { name: 'JAZLAN STEELS', address: 'No.14, Vellalar Street, Ayanambakkam, Maduravoyal, Chennai - 600 095.', gstin: '33EWQPS4454A1ZD', customer: 'Sathyam Traders' } as const
export const RATES = { cgst: 0.09, sgst: 0.09, tds: 0.02 } as const
export const SWITCHES = { TDS_REDUCES_BALANCE: true, INCLUDE_SUNDAYS_IN_WAGES: true } as const
export const WAGE_RATES = { driver: 800, supervisor: 700 } as const
export const MATERIALS = ['MS BORING','MELDING','ROD BIT','ROLLING','GM MELDING','ALUMINIUM','SS (STAINLESS STEEL)','COPPER','COMMERCIAL SCAB','CR PUNCHING','GI PUNCHING'] as const
export const LOADMEN = ['Surender','Nithish','Kulla','Rahul','Vimal','Murugan','Selvam','Ravi'] as const
