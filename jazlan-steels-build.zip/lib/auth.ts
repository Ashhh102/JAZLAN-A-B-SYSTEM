import { canAccessRoute } from './permissions'

export type UserRole = 'accounting' | 'billing'

export type DemoUser = {
  username: string
  password: string
  role: UserRole
  displayName: string
  title: string
}

export const DEMO_USERS: DemoUser[] = [
  { username: 'accounts', password: 'demo123', role: 'accounting', displayName: 'Accounts', title: 'Administrator' },
  { username: 'billing', password: 'demo123', role: 'billing', displayName: 'Billing', title: 'Billing Clerk' },
]

export const SESSION_KEY = 'jazlan-session'

export function authenticate(username: string, password: string) {
  return DEMO_USERS.find((user) => user.username === username.trim().toLowerCase() && user.password === password) ?? null
}

export function getHomePath(role: UserRole) {
  return role === 'accounting' ? '/accounting/dashboard' : '/billing/home'
}

export function isAllowedPath(pathname: string, role: UserRole) {
  return canAccessRoute(role, pathname)
}
