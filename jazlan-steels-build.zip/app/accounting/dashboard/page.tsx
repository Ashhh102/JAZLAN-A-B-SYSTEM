import Page from '@/app/page'

export default function AccountingDashboardPage() {
  return <Page />
}
