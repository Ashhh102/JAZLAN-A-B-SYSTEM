'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { getHomePath, SESSION_KEY, type DemoUser } from '@/lib/auth'
import { canAccessRoute } from '@/lib/permissions'

export default function AccountingCatchAllPage() {
  const router = useRouter()

  useEffect(() => {
    const raw = window.localStorage.getItem(SESSION_KEY)
    const session = raw ? (JSON.parse(raw) as DemoUser) : null
    if (!session) {
      router.replace('/login')
      return
    }
    if (!canAccessRoute(session.role, window.location.pathname)) {
      router.replace(getHomePath(session.role))
      return
    }
    router.replace('/accounting/dashboard')
  }, [router])

  return null
}
