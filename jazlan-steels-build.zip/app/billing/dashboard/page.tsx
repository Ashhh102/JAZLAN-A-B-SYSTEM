'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { getHomePath, SESSION_KEY, type DemoUser } from '@/lib/auth'
import { canAccessRoute } from '@/lib/permissions'

export default function BillingDashboardRedirect() {
  const router = useRouter()

  useEffect(() => {
    const raw = window.localStorage.getItem(SESSION_KEY)
    const session = raw ? (JSON.parse(raw) as DemoUser) : null
    if (!session) {
      router.replace('/login')
      return
    }
    router.replace(canAccessRoute(session.role, window.location.pathname) ? '/billing/home' : getHomePath(session.role))
  }, [router])

  return null
}
