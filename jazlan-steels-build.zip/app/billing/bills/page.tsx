'use client'

import { useEffect, useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Download, FileText, LockKeyhole, Printer, Search, X, LayoutDashboard, FilePlus } from 'lucide-react'
import { WorkspaceShell } from '@/components/workspace-shell'
import { InvoicePreview } from '@/components/invoice-preview'
import { BILLING_KEY, type GeneratedBill } from '@/lib/billing'
import { getHomePath, SESSION_KEY } from '@/lib/auth'
import { can, canAccessRoute } from '@/lib/permissions'
import { COMPANY } from '@/lib/config'

type BillStatus = 'Paid' | 'Partly paid' | 'Pending' | 'Cancelled'
type BillRow = { id: string; invoiceNo: string; invoiceDate: string; customer: string; tripId: string; vehicle: string; material: string; weight: number; rate: number; taxableAmount: number; cgst: number; sgst: number; tds: number; grandTotal: number; netPayable: number; status: BillStatus; pending?: number; legacy?: boolean; eway: string; cancelledReason?: string; address?: string; gstin?: string; items?: GeneratedBill['items']; subtotal?: number; roundOff?: number; locked?: boolean }

const statuses: BillStatus[] = ['Paid', 'Partly paid', 'Pending', 'Cancelled']
const periodBills: BillRow[] = Array.from({ length: 14 }, (_, index) => {
  const serial = String(61 + index).padStart(3, '0')
  const grandTotal = 185000 + index * 6325
  const tds = Math.round(grandTotal * 0.02)
  return { id: `period-${serial}`, invoiceNo: `SMT/26-27/${serial}`, invoiceDate: `2026-${index < 7 ? '05' : '05'}-${String(18 + (index % 13)).padStart(2, '0')}`, customer: COMPANY.customer, tripId: `TRIP-${serial}`, vehicle: ['TN 18 AB 4421', 'TN 18 CD 7712', 'TN 18 EF 1208'][index % 3], material: ['MS BORING', 'MELDING', 'ROD BIT'][index % 3], weight: 12400 + index * 180, rate: 37.2, taxableAmount: grandTotal / 1.18, cgst: grandTotal * 0.09 / 1.18, sgst: grandTotal * 0.09 / 1.18, tds, roundOff: 0, grandTotal, netPayable: grandTotal - tds, status: index < 11 ? 'Paid' : index === 11 ? 'Partly paid' : 'Pending', eway: `351026${String(900000 + index).padStart(6, '0')}` }
})
const legacyBills: BillRow[] = [1, 2, 3].map((n) => ({ ...periodBills[0], id: `legacy-${n}`, invoiceNo: `SMT/25-26/${String(120 + n).padStart(3, '0')}`, tripId: `LEGACY-${n}`, invoiceDate: `2026-04-${String(10 + n).padStart(2, '0')}`, grandTotal: 142000 + n * 4500, netPayable: 138000 + n * 4500, status: 'Paid', legacy: true, eway: `351025${String(800000 + n).padStart(6, '0')}` }))

export default function BillsPage() {
  const router = useRouter()
  const [bills, setBills] = useState<BillRow[]>(periodBills)
  const [selected, setSelected] = useState<BillRow | null>(null)
  const [query, setQuery] = useState('')
  const [status, setStatus] = useState('All')
  const [customer, setCustomer] = useState('All')
  const [dateRange, setDateRange] = useState('This month')
  const [cancelTarget, setCancelTarget] = useState<BillRow | null>(null)
  const [reason, setReason] = useState('')
  const [page, setPage] = useState(1)

  useEffect(() => {
    const session = JSON.parse(localStorage.getItem(SESSION_KEY) || 'null')
    if (!session) { router.replace('/login'); return }
    if (!canAccessRoute(session.role, window.location.pathname)) { router.replace(getHomePath(session.role)); return }
    const created = JSON.parse(localStorage.getItem(BILLING_KEY) || '[]') as GeneratedBill[]
    if (created.length) setBills((current) => [...created.map((bill) => ({ ...bill, id: bill.invoiceNo, taxableAmount: bill.subtotal, invoiceDate: '2026-05-31', vehicle: 'TN 18 AB 4421', material: bill.items[0]?.material || 'MS BORING', weight: bill.items[0]?.quantity || 0, rate: bill.items[0]?.rate || 0, status: 'Pending' as BillStatus, tds: bill.tds, eway: '351026999999' })), ...current.filter((row) => !created.some((item) => item.invoiceNo === row.invoiceNo))])
  }, [router])

  const allBills = useMemo(() => [...bills, ...legacyBills.filter((bill) => !bills.some((row) => row.id === bill.id))].sort((a, b) => b.invoiceNo.localeCompare(a.invoiceNo)), [bills])
  const filtered = useMemo(() => allBills.filter((bill) => (bill.invoiceNo + bill.vehicle).toLowerCase().includes(query.toLowerCase()) && (status === 'All' || bill.status === status) && (customer === 'All' || bill.customer === customer) && (dateRange === 'This month' ? bill.invoiceDate.startsWith('2026-05') : dateRange === 'Last month' ? bill.invoiceDate.startsWith('2026-04') : dateRange === 'Last 3 months' ? bill.invoiceDate >= '2026-03-01' : dateRange === 'Financial year' ? bill.invoiceDate >= '2026-04-01' : bill.invoiceDate >= '2026-01-01')), [allBills, query, status, customer, dateRange])
  const visible = filtered.filter((bill) => bill.status !== 'Cancelled')
  const pageRows = filtered.slice((page - 1) * 10, page * 10)
  const totals = visible.reduce((sum, bill) => ({ invoiced: sum.invoiced + bill.taxableAmount, receivable: sum.receivable + bill.netPayable, pending: sum.pending + (bill.status === 'Pending' || bill.status === 'Partly paid' ? bill.netPayable : 0) }), { invoiced: 0, receivable: 0, pending: 0 })
  const money = (value: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(value)

  function cancelBill() {
    if (!cancelTarget || !reason.trim()) return
    setBills((current) => current.map((bill) => bill.id === cancelTarget.id ? { ...bill, status: 'Cancelled', cancelledReason: reason.trim() } : bill))
    setCancelTarget(null); setReason('')
  }

  function exportCsv() {
    const csv = ['Invoice No.,Date,Customer,Vehicle,Grand Total,TDS,Net Payable,Status', ...visible.map((bill) => [bill.invoiceNo, bill.invoiceDate, bill.customer, bill.vehicle, bill.grandTotal, bill.tds, bill.netPayable, bill.status].join(','))].join('\n')
    const link = document.createElement('a'); link.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); link.download = 'jazlan-bills.csv'; link.click(); URL.revokeObjectURL(link.href)
  }

  return <WorkspaceShell workspace="Billing" navItems={[{ label:'Home', href:'/billing/home', icon:LayoutDashboard }, { label:'Create New Bill', href:'/billing/new', icon:FilePlus }, { label:'View Bills', href:'/billing/bills', icon:FileText }]} user={{ name:'Billing', role:'Billing Clerk', initials:'BC' }} breadcrumb="BILLING / VIEW BILLS" title="Bills" subtitle="Search, view, print or cancel issued bills."><section className="billing-content"><div className="page-heading"><div><span className="eyebrow">ACCOUNTS RECEIVABLE</span><h2>All bills</h2><p className="caption">Invoices linked to trip ledger activity and payment allocations.</p></div>{can('billing', 'bills.create') && <button className="primary-btn" onClick={() => router.push('/billing/new')}><FileText data-icon="inline-start" /> New bill</button>}</div>
      <div className="summary-grid"><Summary label="Bills this period" value={String(bills.filter((bill) => !bill.legacy && bill.status !== 'Cancelled').length)} /><Summary label="Total invoiced" value={money(totals.invoiced)} /><Summary label="Net receivable" value={money(totals.receivable)} /><Summary label="Pending amount" value={money(totals.pending)} accent /></div>
      <div className="billing-card bills-card"><div className="bills-toolbar"><label className="search-field"><Search data-icon="inline-start" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search invoice or vehicle" /></label><select value={status} onChange={(event) => setStatus(event.target.value)}><option>All</option>{statuses.map((item) => <option key={item}>{item}</option>)}</select><select value={customer} onChange={(event) => setCustomer(event.target.value)}><option>All</option><option>{COMPANY.customer}</option></select><select value={dateRange} onChange={(event) => setDateRange(event.target.value)}><option>This month</option><option>Last month</option><option>Last 3 months</option><option>Financial year</option><option>Custom</option></select><button className="secondary-btn export-btn" onClick={exportCsv}><Download data-icon="inline-start" /> Export CSV</button></div>
        <div className="table-wrap"><table><thead><tr><th>Invoice No.</th><th>Date</th><th>Customer</th><th>Vehicle</th><th>Grand Total</th><th>TDS</th><th>Net Payable</th><th>Status</th><th>Actions</th></tr></thead><tbody>{pageRows.map((bill, index) => <tr key={`bill-row-${bill.id}-${bill.invoiceNo}-${index}`} className={bill.status === 'Cancelled' ? 'row-cancelled' : ''}><td><button className="invoice-link" onClick={() => setSelected(bill)}>{bill.invoiceNo}</button>{bill.legacy && <span className="legacy-pill">Legacy</span>}</td><td>{bill.invoiceDate}</td><td>{bill.customer}</td><td>{bill.vehicle}</td><td>{money(bill.grandTotal)}</td><td>{money(bill.tds)}</td><td>{money(bill.netPayable)}</td><td><span className={`status-pill ${bill.status.toLowerCase().replace(' ', '-')}`}>{bill.status}</span></td><td><div className="row-actions"><button className="text-btn" onClick={() => setSelected(bill)}>View</button>{can('billing', 'bills.cancel') && <button className="text-btn danger-text" onClick={() => setCancelTarget(bill)}>Cancel</button>}<span className="lock-icon" title="Locked. Cancel and reissue to correct."><LockKeyhole /></span></div></td></tr>)}</tbody><tfoot><tr><td colSpan={4}>Totals</td><td>{money(visible.reduce((sum, bill) => sum + bill.grandTotal, 0))}</td><td>{money(visible.reduce((sum, bill) => sum + bill.tds, 0))}</td><td>{money(totals.receivable)}</td><td colSpan={2}>{visible.length} bills</td></tr></tfoot></table></div><div className="pagination-bar"><span>Showing {filtered.length ? ((page - 1) * 10) + 1 : 0}–{Math.min(page * 10, filtered.length)} of {filtered.length}</span><div><button className="secondary-btn" disabled={page === 1} onClick={() => setPage((value) => value - 1)}>Previous</button><button className="secondary-btn" disabled={page * 10 >= filtered.length} onClick={() => setPage((value) => value + 1)}>Next</button></div></div></div></section>
    {selected && <div className="modal-backdrop" onClick={() => setSelected(null)}><aside className="invoice-drawer" onClick={(event) => event.stopPropagation()}><div className="drawer-head"><div><span className="eyebrow">INVOICE VIEW</span><h2>{selected.invoiceNo}</h2></div><button className="icon-btn" onClick={() => setSelected(null)} aria-label="Close"><X /></button></div><InvoicePreview invoice={selected as GeneratedBill} /><div className="drawer-actions"><button className="secondary-btn" onClick={() => window.print()}><Printer data-icon="inline-start" /> Print</button><button className="primary-btn" onClick={() => window.print()}><Download data-icon="inline-start" /> Download PDF</button></div></aside></div>}
    {cancelTarget && <div className="modal-backdrop" onClick={() => setCancelTarget(null)}><div className="confirm-dialog" onClick={(event) => event.stopPropagation()}><span className="eyebrow">CANCEL INVOICE</span><h2>Cancel {cancelTarget.invoiceNo}?</h2><p>This keeps the record, cancels its linked trip, and releases payment allocations.</p><textarea value={reason} onChange={(event) => setReason(event.target.value)} placeholder="Reason is required" /><div className="drawer-actions"><button className="secondary-btn" onClick={() => setCancelTarget(null)}>Keep bill</button><button className="danger-btn" disabled={!reason.trim()} onClick={cancelBill}>Cancel invoice</button></div></div></div>}
  </WorkspaceShell>
}
function Summary({ label, value, accent = false }: { label: string; value: string; accent?: boolean }) { return <div className={`summary-card ${accent ? 'accent' : ''}`}><span>{label}</span><strong>{value}</strong></div> }
