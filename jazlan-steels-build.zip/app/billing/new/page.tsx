'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Plus, Trash2, Printer, Eye, X, LayoutDashboard, FilePlus, FileText } from 'lucide-react'
import { WorkspaceShell } from '@/components/workspace-shell'
import { numberToWordsINR, round2 } from '@/lib/calculations'
import { InvoicePreview } from '@/components/invoice-preview'
import { getHomePath, SESSION_KEY } from '@/lib/auth'
import { can, canAccessRoute } from '@/lib/permissions'
import { materials, nextInvoiceNo, nextTripId, saveGeneratedBill, type BillItem, type GeneratedBill } from '@/lib/billing'

type DraftItem = BillItem & { id:number }
const money = (value:number) => new Intl.NumberFormat('en-IN', { style:'currency', currency:'INR', minimumFractionDigits:2 }).format(value)

export default function BillingNewPage() {
  const router = useRouter()
  const [authorized, setAuthorized] = useState(false)
  const [vehicle, setVehicle] = useState('')
  const [gstin, setGstin] = useState('33ABCDE1234F1Z5')
  const [sameShipping, setSameShipping] = useState(true)
  const [items, setItems] = useState<DraftItem[]>([{ id:1, material:materials[0], quantity:0, rate:0, hsn:'7204' }])
  const [showConfirm, setShowConfirm] = useState(false)
 const [showPreview, setShowPreview] = useState(false)
  const previewCloseRef = useRef<HTMLButtonElement>(null)
  const [error, setError] = useState('')

  useEffect(() => {
    try { const session = JSON.parse(window.localStorage.getItem(SESSION_KEY) || 'null'); if (!session) router.replace('/login'); else if (!canAccessRoute(session.role, window.location.pathname)) router.replace(getHomePath(session.role)); else setAuthorized(true) } catch { router.replace('/login') }
  }, [router])

  useEffect(() => {
    if (!showPreview) return
    const previousFocus = document.activeElement as HTMLElement | null
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setShowPreview(false)
    }
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    document.addEventListener('keydown', handleKeyDown)
    previewCloseRef.current?.focus()
    return () => {
      document.removeEventListener('keydown', handleKeyDown)
      document.body.style.overflow = previousOverflow
      previousFocus?.focus()
    }
  }, [showPreview])

  const totals = useMemo(() => {
    const subtotal = round2(items.reduce((sum, item) => sum + item.quantity * item.rate, 0))
    const cgst = round2(subtotal * .09), sgst = round2(subtotal * .09)
    const beforeRound = subtotal + cgst + sgst, grandTotal = Math.ceil(beforeRound)
    const tds = round2(subtotal * .02)
    return { quantity: items.reduce((sum,item) => sum + Number(item.quantity || 0), 0), subtotal, cgst, sgst, roundOff:round2(grandTotal - beforeRound), grandTotal, tds, netPayable:round2(grandTotal - tds) }
  }, [items])

  const previewInvoice: GeneratedBill = { invoiceNo: nextInvoiceNo(), invoiceDate: '2026-05-31', vehicle: vehicle || '—', customer: 'Sathyam Traders', address: '12 Market Road, Chennai', gstin, items: items.filter(item => item.quantity > 0 || item.rate > 0).map(({ id, ...item }) => item), ...totals, status: 'Pending', locked: false, tripId: 'TR-PREVIEW' }

  const updateItem = (id:number, key:keyof BillItem, value:string) => setItems(current => current.map(item => item.id === id ? { ...item, [key]: key === 'material' || key === 'hsn' ? value : Number(value) } : item))
  const generate = () => {
    if (!vehicle.trim() || !items.some(item => item.quantity > 0 && item.rate > 0)) { setError('Enter a vehicle number and at least one item with quantity and rate.'); setShowConfirm(false); return }
    if (!/^[A-Za-z0-9]{15}$/.test(gstin)) { setError('GSTIN must be exactly 15 characters.'); setShowConfirm(false); return }
    saveGeneratedBill({ invoiceNo:nextInvoiceNo(), invoiceDate:'2026-05-31', vehicle, customer:'Sathyam Traders', address:'12 Market Road, Chennai', gstin, items:items.filter(item => item.quantity > 0).map(({id,...item}) => item), ...totals, status:'Pending', locked:true, tripId:nextTripId() })
    window.alert('Bill generated and locked. Matching trip added to the accounting ledger.')
    router.push('/billing/bills')
  }

  if (!authorized) return <main className="billing-placeholder"><div className="login-brand-mark">JZ</div><p>Loading billing workspace...</p></main>
  return <WorkspaceShell workspace="Billing" navItems={[{ label:'Home', href:'/billing/home', icon:LayoutDashboard }, { label:'Create New Bill', href:'/billing/new', icon:FilePlus }, { label:'View Bills', href:'/billing/bills', icon:FileText }]} user={{ name:'Billing', role:'Billing Clerk', initials:'BC' }} breadcrumb="BILLING / CREATE NEW BILL" title="Create new bill" subtitle="Fill the details, review the live invoice, then generate."><section className="billing-form-shell"><div className="billing-form-head"><div><span className="eyebrow">INVOICE WORKFLOW</span><h2>Create new bill</h2><p>Complete the sale details, verify totals, then lock the generated invoice.</p></div><span className="auto-badge">{nextInvoiceNo()} · Auto</span></div>
      <div className="billing-grid"><section className="billing-card"><h3>Invoice details</h3><div className="field-grid"><label>Invoice No.<input value={nextInvoiceNo()} readOnly/><small>Auto generated</small></label><label>Invoice Date<input type="date" defaultValue="2026-05-31"/></label><label>Date of Supply<input type="date" defaultValue="2026-05-31"/></label><label>PO No. <span className="muted">(optional)</span><input placeholder="Optional purchase order"/></label></div></section>
      <section className="billing-card"><h3>Transport</h3><div className="field-grid"><label>Vehicle No.<input value={vehicle} onChange={e=>setVehicle(e.target.value.toUpperCase())} placeholder="TN 00 AB 0000"/><small>Required for generation</small></label><label>E-Way Bill No. <span className="muted">(optional)</span><input inputMode="numeric" maxLength={12} placeholder="12 digits"/></label></div>{totals.subtotal > 50000 && <p className="billing-warning">Taxable value is above ₹50,000. An E-Way Bill number is recommended.</p>}</section>
      <section className="billing-card"><h3>Billing address</h3><div className="field-grid"><label>Customer<select defaultValue="Sathyam Traders"><option>Sathyam Traders</option></select></label><label>GSTIN<input value={gstin} maxLength={15} onChange={e=>setGstin(e.target.value.toUpperCase())}/><small>{gstin.length}/15 characters</small></label><label className="span-two">Address<textarea defaultValue="12 Market Road, Chennai" rows={2}/></label></div></section>
      <section className="billing-card"><h3>Shipping address</h3><label className="check-row"><input type="checkbox" checked={sameShipping} onChange={e=>setSameShipping(e.target.checked)}/> Same as billing</label>{!sameShipping && <div className="field-grid"><label>Name<input placeholder="Consignee name"/></label><label>Address<textarea rows={2} placeholder="Shipping address"/></label></div>}</section>
      <section className="billing-card billing-items"><div className="card-title-row"><h3>Items</h3><button className="secondary-btn" onClick={()=>setItems(current=>[...current,{id:Date.now(),material:materials[0],quantity:0,rate:0,hsn:'7204'}])}><Plus/>Add item</button></div><div className="items-table"><div className="items-head"><span>Material</span><span>HSN</span><span>Quantity (kg)</span><span>Unit</span><span>Rate</span><span>Amount</span><span /></div>{items.map(item=><div className="items-row" key={item.id}><select value={item.material} onChange={e=>updateItem(item.id,'material',e.target.value)}>{materials.map(material=><option key={material}>{material}</option>)}</select><input value="7204" readOnly/><input type="number" min="0" value={item.quantity || ''} onChange={e=>updateItem(item.id,'quantity',e.target.value)}/><input value="KGS" readOnly/><input type="number" min="0" step="0.01" value={item.rate || ''} onChange={e=>updateItem(item.id,'rate',e.target.value)}/><strong>{money(item.quantity * item.rate)}</strong><button className="icon-btn" aria-label="Remove item" onClick={()=>setItems(current=>current.length === 1 ? current : current.filter(row=>row.id !== item.id))}><Trash2/></button></div>)}</div></section>
      <aside className="billing-card billing-summary"><h3>Totals</h3><div><span>Total Qty</span><strong>{totals.quantity.toLocaleString('en-IN')} kg</strong></div><div><span>Sub Total</span><strong>{money(totals.subtotal)}</strong></div><div><span>CGST @ 9%</span><strong>{money(totals.cgst)}</strong></div><div><span>SGST @ 9%</span><strong>{money(totals.sgst)}</strong></div><div><span>Round-off</span><strong>{totals.roundOff >= 0 ? '+' : ''}{money(totals.roundOff)}</strong></div><div className="summary-total"><span>Grand Total</span><strong>{money(totals.grandTotal)}</strong></div><div><span>Less: TDS @ 2%</span><strong>{money(totals.tds)}</strong></div><div className="summary-total"><span>Net Amount Payable</span><strong>{money(totals.netPayable)}</strong></div><p className="amount-words">{numberToWordsINR(totals.grandTotal)}</p></aside></div>
      {error && <p className="form-error">{error}</p>}<div className="billing-actions"><button className="secondary-btn preview-invoice-trigger" onClick={()=>setShowPreview(true)}><Eye data-icon="inline-start"/> Preview</button>{can('billing', 'bills.create') && <button className="primary-btn" onClick={()=>setShowConfirm(true)}>Generate Bill</button>}</div>
    </section>{showPreview && <div className="invoice-preview-modal-backdrop" role="presentation" onClick={()=>setShowPreview(false)}><div className="invoice-preview-modal" role="dialog" aria-modal="true" aria-labelledby="invoice-preview-title" onClick={event=>event.stopPropagation()}><header className="invoice-preview-modal-header"><h2 id="invoice-preview-title">Invoice Preview</h2><button ref={previewCloseRef} className="icon-btn" onClick={()=>setShowPreview(false)} aria-label="Close invoice preview"><X /></button></header><div className="invoice-preview-modal-actions"><button className="secondary-btn" onClick={()=>window.print()}><Printer data-icon="inline-start"/> Print / Download PDF</button></div><div className="invoice-preview-modal-scroll"><InvoicePreview invoice={previewInvoice}/></div><footer className="invoice-preview-modal-footer"><button className="secondary-btn" onClick={()=>setShowPreview(false)}>Close</button></footer></div></div>}<section className="billing-preview-card"><div className="preview-toolbar"><div><span className="eyebrow">LIVE PREVIEW</span><h2>Invoice preview</h2></div><button className="secondary-btn" onClick={()=>window.print()}><Printer data-icon="inline-start"/>Print / Download PDF</button></div><InvoicePreview invoice={previewInvoice}/></section>{showConfirm && <div className="modal-backdrop"><div className="modal"><h3>Generate and lock bill?</h3><p>A generated bill is locked and cannot be edited. Continue?</p><div className="modal-actions"><button className="secondary-btn" onClick={()=>setShowConfirm(false)}>Cancel</button><button className="primary-btn" onClick={generate}>Confirm and generate</button></div></div></div>}</WorkspaceShell>
}
