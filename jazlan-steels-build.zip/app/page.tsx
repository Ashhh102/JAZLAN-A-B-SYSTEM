'use client'

import { useEffect, useMemo, useState } from 'react'
import { Bell, ClipboardList, LayoutDashboard, Menu, Plus, ReceiptIndianRupee, Settings, Users, WalletCards, X } from 'lucide-react'
import { REFERENCE_DATE } from '@/lib/config'
import { formatDate, formatINR, formatKg, purchaseAmount, saleTotals, type PayableBill } from '@/lib/calculations'
import { getHomePath, SESSION_KEY } from '@/lib/auth'
import { can, canAccessRoute } from '@/lib/permissions'
import { WorkspaceShell } from '@/components/workspace-shell'

type Trip = { id: string; date: string; vehicle: string; material: string; kg: number; rate: number; supplier: string; driver: string; purchaseKg?: number; purchaseRate?: number; status: 'Complete' | 'Incomplete' }
type Payment = { id: string; date: string; amount: number; reference: string; remarks?: string }
type SupplierPayment = Payment & { supplier: string }

const trips: Trip[] = [
  ['TR-1011','2026-05-02','4452','MS BORING',6675,33.7,'GK','Kali',6700,31,'Complete'],['TR-1012','2026-05-05','4452','MS BORING',1500,34.7,'TBI','Kali',1500,31.5,'Complete'],['TR-1013','2026-05-05','4452','ROD BIT',5350,36.7,'TBI','Kali',5350,33.5,'Complete'],['TR-1014','2026-05-07','4452','MS BORING',9310,34,'GK','Kali',9310,31.2,'Complete'],['TR-1015','2026-05-12','4452','MS BORING',6070,33,'GK','Kali',6070,30.4,'Complete'],['TR-1016','2026-05-19','4452','MS BORING',7000,31.7,'GK','Kali',7000,29.2,'Complete'],['TR-1017','2026-05-20','TN13AM2184','ROD BIT',18350,34,'BK (Bee Kay Steel)','Kali',18350,31.4,'Complete'],['TR-1018','2026-05-21','4452','MELDING',18960,34,'BK (Bee Kay Steel)','Kali',18960,31.3,'Complete'],['TR-1019','2026-05-22','TN13AM2184','ROLLING',20400,34,'BK (Bee Kay Steel)','Kali',20400,31.5,'Complete'],['TR-1020','2026-05-23','4452','MS BORING',18330,33.5,'BK (Bee Kay Steel)','Kali',18330,30.9,'Complete'],['TR-1021','2026-05-25','TN18BJ2540','GM MELDING',12350,32.5,'BK (Bee Kay Steel)','Kali',12350,30,'Complete'],['TR-1022','2026-05-26','4452','ROLLING',13210,31,'BK (Bee Kay Steel)','Kali',13210,28.6,'Complete'],['TR-1023','2026-05-27','TN18BJ2540','MELDING',8620,30.5,'BK (Bee Kay Steel)','',undefined,undefined,'Incomplete'],['TR-1024','2026-05-30','4452','MS BORING',13940,33,'GK','',undefined,undefined,'Incomplete'],
].map((x) => ({ id:x[0], date:x[1], vehicle:x[2], material:x[3], kg:x[4], rate:x[5], supplier:x[6], driver:x[7], purchaseKg:x[8], purchaseRate:x[9], status:x[10] }))

const netValues = [260939.05,60378,227760.10,367186.20,232359.80,257404,723724,747782.20,804576,712303.90,465595.50,475031.80,304975.80,533623.60]
const bills: PayableBill[] = netValues.map((net, i) => ({ invoiceNo:`SMT/26-27/${String(i + 61).padStart(3,'0')}`, date:trips[i].date, grandTotalPaise:Math.round(net / .98 * 100), tdsPaise:Math.round((net / .98 - net) * 100) }))
const initialCustomer: Payment[] = [300000,275000,330000,250000,500000,250000,650000,600000,700000,600000,700000].map((amount, i) => ({ id:`customer-${i}`, date:`2026-05-${[6,9,14,18,20,22,24,26,28,30,31][i]}`, amount, reference:`HDFCR52605${String(i + 1).padStart(5,'0')}` }))
const initialSupplier: SupplierPayment[] = [
  { id:'supplier-1', date:'2026-05-12', supplier:'TBI', amount:200000, reference:'HDFCS5260512002' }, { id:'supplier-2', date:'2026-05-15', supplier:'BK (Bee Kay Steel)', amount:1500000, reference:'HDFCS5260515003' }, { id:'supplier-3', date:'2026-05-28', supplier:'GK', amount:800000, reference:'HDFCS5260528001' }, { id:'supplier-4', date:'2026-05-29', supplier:'BK (Bee Kay Steel)', amount:1100000, reference:'HDFCS5260529004' },
]
const suppliers = ['GK','TBI','BK (Bee Kay Steel)']
const money = (n:number) => formatINR(n)
const paise = (n:number) => Math.round(n * 100)
const dateInput = (date:string) => date

function Stat({ label, value, highlight }: { label:string; value:string; highlight?:boolean }) { return <div className={`stat-card ${highlight ? 'highlight' : ''}`}><span>{label}</span><strong>{value}</strong></div> }
function Badge({ status }: { status:string }) { return <span className={`status ${status.toLowerCase().replace(' ','-')}`}>{status}</span> }
function Table({ headers, children }: { headers:string[]; children:React.ReactNode }) { return <div className="table-wrap"><table><thead><tr>{headers.map((header) => <th key={header}>{header}</th>)}</tr></thead><tbody>{children}</tbody></table></div> }

function Payments({ notify, setPending }: { notify:(message:string)=>void; setPending:(value:number)=>void }) {
  const [tab, setTab] = useState<'customer'|'supplier'>('customer')
  const [customerPayments, setCustomerPayments] = useState(initialCustomer)
  const [supplierPayments, setSupplierPayments] = useState(initialSupplier)
  const [formOpen, setFormOpen] = useState(false)
  const [drawer, setDrawer] = useState<string | null>(null)
  const [query, setQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('All')
  const [amount, setAmount] = useState('')
  const [reference, setReference] = useState('')
  const [supplier, setSupplier] = useState(suppliers[0])

  const allocations = useMemo(() => {
    const result: Record<string, number> = {}
    let remaining = 5155000
    customerPayments.forEach((payment) => { remaining += payment.amount - payment.amount; })
    // The seed is intentionally replayed oldest-first; newly entered payments are replayed after it.
    const applied: Record<string, number> = {}
    const ordered = [...bills].sort((a,b) => a.date.localeCompare(b.date) || a.invoiceNo.localeCompare(b.invoiceNo))
    for (const payment of customerPayments) {
      let left = paise(payment.amount)
      for (const bill of ordered) {
        const net = bill.grandTotalPaise - bill.tdsPaise
        const used = applied[bill.invoiceNo] || 0
        const take = Math.min(left, Math.max(0, net - used))
        if (take) applied[bill.invoiceNo] = used + take
        left -= take
        if (!left) break
      }
    }
    Object.entries(applied).forEach(([key, value]) => { result[key] = value / 100 })
    return result
  }, [customerPayments])
  const received = Object.values(allocations).reduce((sum, value) => sum + value, 0)
  const billed = 6280082
  const tds = 106442.05
  const pending = Math.max(0, 6173639.95 - received)
  const unallocated = Math.max(0, customerPayments.reduce((s,p) => s + p.amount, 0) - received)
  useEffect(() => { setPending(pending) }, [pending, setPending])

  const rows = bills.map((bill, index) => {
    const receivedAmount = allocations[bill.invoiceNo] || 0
    const net = netValues[index]
    const pendingAmount = Math.max(0, net - receivedAmount)
    const status = pendingAmount === 0 ? 'Paid' : receivedAmount > 0 ? 'Partly paid' : 'Pending'
    return { bill, index, receivedAmount, net, pendingAmount, status }
  }).filter((row) => row.bill.invoiceNo.toLowerCase().includes(query.toLowerCase()) && (statusFilter === 'All' || row.status === statusFilter))

  const record = () => {
    const value = Number(amount)
    const clean = reference.trim()
    const allRefs = [...customerPayments, ...supplierPayments].map((p) => p.reference)
    if (!value || value <= 0 || !clean || allRefs.includes(clean)) return
    if (tab === 'customer') setCustomerPayments((current) => [...current, { id:`customer-${Date.now()}`, date:REFERENCE_DATE, amount:value, reference:clean }])
    else setSupplierPayments((current) => [...current, { id:`supplier-${Date.now()}`, date:REFERENCE_DATE, amount:value, reference:clean, supplier }])
    notify(`Payment of ${money(value)} recorded`); setAmount(''); setReference(''); setFormOpen(false)
  }
  const deleteCustomer = (id:string) => { if (window.confirm('Deleting this payment will reopen the bills it covered')) setCustomerPayments((current) => current.filter((payment) => payment.id !== id)) }

  if (tab === 'supplier') {
    const purchased = 4240516
    const paid = supplierPayments.reduce((sum,payment) => sum + payment.amount, 0)
    return <section className="content"><div className="hero-row"><div><h2>Payments &amp; credit</h2><p>Money received from Sathyam Traders and money owed to suppliers.</p></div><button className="primary-btn" onClick={() => setFormOpen(true)}><Plus/>Record payment</button></div><div className="tabs"><button onClick={() => setTab('customer')}>Customer receivables</button><button className="active">Supplier payables</button></div><div className="stat-grid three"><Stat label="Total purchased" value={money(purchased)}/><Stat label="Paid to suppliers" value={money(paid)}/><Stat label="Balance owed" value={money(purchased - paid)} highlight/></div><Table headers={['Supplier','Total purchased','Paid','Balance owed','Last payment']}><tr className="totals-row"><td>Total</td><td>{money(purchased)}</td><td>{money(paid)}</td><td>{money(purchased - paid)}</td><td>31/05/2026</td></tr>{suppliers.map((name) => <tr key={name} onClick={() => setDrawer(name)}><td>{name}</td><td>{money(name === 'GK' ? 887100 : name === 'TBI' ? 226475 : 3126941)}</td><td>{money(supplierPayments.filter((p) => p.supplier === name).reduce((s,p) => s + p.amount, 0))}</td><td>{money((name === 'GK' ? 887100 : name === 'TBI' ? 226475 : 3126941) - supplierPayments.filter((p) => p.supplier === name).reduce((s,p) => s + p.amount, 0))}</td><td>{formatDate(supplierPayments.find((p) => p.supplier === name)?.date || REFERENCE_DATE)}</td></tr>)}</Table><h3 className="section-title">Payments to suppliers</h3><Table headers={['Date','Supplier','RTGS Reference','Amount','Actions']}>{supplierPayments.map((payment) => <tr key={payment.id}><td>{formatDate(payment.date)}</td><td>{payment.supplier}</td><td>{payment.reference}</td><td className="numeric">{money(payment.amount)}</td><td><button className="text-btn" onClick={() => setDrawer(payment.id)}>View</button></td></tr>)}</Table>{formOpen && <PaymentModal tab="supplier" amount={amount} setAmount={setAmount} reference={reference} setReference={setReference} supplier={supplier} setSupplier={setSupplier} onSave={record} onClose={() => setFormOpen(false)}/>} {drawer && <Drawer title={suppliers.includes(drawer) ? drawer : 'Supplier payment'} onClose={() => setDrawer(null)}><p>Supplier payment details and transaction history.</p></Drawer>}</section>
  }
  return <section className="content"><div className="hero-row"><div><h2>Payments &amp; credit</h2><p>Money received from Sathyam Traders and money owed to suppliers.</p></div><button className="primary-btn" onClick={() => setFormOpen(true)}><Plus/>Record payment</button></div><div className="tabs"><button className="active">Customer receivables</button><button onClick={() => setTab('supplier')}>Supplier payables</button></div><div className="stat-grid four"><Stat label="Total billed" value={money(billed)}/><Stat label="TDS deducted" value={money(tds)}/><Stat label="Received by RTGS" value={money(received)}/><Stat label="Balance remaining" value={money(pending)} highlight/></div><p className="caption">Net payable = Billed amount minus TDS. Balance = Net payable minus received. As on 31/05/2026.</p><div className="credit-card"><div><span>Credit limit</span><strong>{money(7500000)}</strong></div><div><span>Outstanding</span><strong>{money(pending)}</strong></div><div><span>Available credit</span><strong>{money(7500000 - pending)}</strong></div><div className="progress"><div style={{width:`${Math.min(100, pending / 7500000 * 100)}%`}}/></div><small>Sathyam Traders credit utilisation</small></div><div className="toolbar"><input placeholder="Search invoice number" value={query} onChange={(event) => setQuery(event.target.value)}/><select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}><option>All</option><option>Paid</option><option>Partly paid</option><option>Pending</option></select><button className="secondary-btn" onClick={() => { const csv = ['Invoice No,Date,Net Payable,Received,Pending', ...rows.map((r) => `${r.bill.invoiceNo},${r.bill.date},${r.net},${r.receivedAmount},${r.pendingAmount}`)].join('\n'); const url = URL.createObjectURL(new Blob([csv], {type:'text/csv'})); const link = document.createElement('a'); link.href = url; link.download = 'bills.csv'; link.click(); URL.revokeObjectURL(url) }}>Export CSV</button></div><Table headers={['Invoice No.','Date','Billed Amount','TDS (2%)','Net Payable','Received','Pending','Status']}>{rows.map((row) => <tr key={row.bill.invoiceNo} onClick={() => setDrawer(row.bill.invoiceNo)}><td>{row.bill.invoiceNo}</td><td>{formatDate(row.bill.date)}</td><td className="numeric">{money(row.bill.grandTotalPaise / 100)}</td><td className="numeric">{money(row.bill.tdsPaise / 100)}</td><td className="numeric">{money(row.net)}</td><td className="numeric">{money(row.receivedAmount)}</td><td className="numeric">{money(row.pendingAmount)}</td><td><Badge status={row.status}/></td></tr>)}<tr className="totals-row"><td>Totals</td><td/><td>{money(billed)}</td><td>{money(tds)}</td><td>{money(6173639.95)}</td><td>{money(received)}</td><td>{money(pending)}</td><td/></tr></Table><h3 className="section-title">Payments received</h3><Table headers={['Date','RTGS Reference','Amount','Applied To','Actions']}>{customerPayments.map((payment) => <tr key={payment.id}><td>{formatDate(payment.date)}</td><td>{payment.reference}</td><td className="numeric">{money(payment.amount)}</td><td>Oldest bills first</td><td><button className="text-btn" onClick={() => setDrawer(payment.id)}>View</button> <button className="text-btn danger" onClick={() => deleteCustomer(payment.id)}>Delete</button></td></tr>)}</Table>{formOpen && <PaymentModal tab="customer" amount={amount} setAmount={setAmount} reference={reference} setReference={setReference} supplier={supplier} setSupplier={setSupplier} onSave={record} onClose={() => setFormOpen(false)}/>} {drawer && <Drawer title={drawer.startsWith('SMT') ? drawer : 'Payment allocation'} onClose={() => setDrawer(null)}><p>Allocation history is calculated oldest-first from the current payment register.</p></Drawer>}</section>
}

function PaymentModal({ tab, amount, setAmount, reference, setReference, supplier, setSupplier, onSave, onClose }: { tab:'customer'|'supplier'; amount:string; setAmount:(v:string)=>void; reference:string; setReference:(v:string)=>void; supplier:string; setSupplier:(v:string)=>void; onSave:()=>void; onClose:()=>void }) { return <div className="modal-backdrop"><div className="modal"><div className="modal-head"><h3>Record {tab === 'customer' ? 'customer' : 'supplier'} payment</h3><button onClick={onClose}><X/></button></div><label>Date<input type="date" defaultValue={dateInput(REFERENCE_DATE)} max={REFERENCE_DATE}/></label>{tab === 'supplier' && <label>Supplier<select value={supplier} onChange={(event) => setSupplier(event.target.value)}>{suppliers.map((name) => <option key={name}>{name}</option>)}</select></label>}<label>Amount<input type="number" min="1" value={amount} onChange={(event) => setAmount(event.target.value)} placeholder="0.00"/></label><label>RTGS Reference<input value={reference} onChange={(event) => setReference(event.target.value)} placeholder="Required and unique"/></label><div className="modal-actions"><button className="secondary-btn" onClick={onClose}>Cancel</button><button className="primary-btn" onClick={onSave}>Save payment</button></div></div></div> }
function Drawer({ title, children, onClose }: { title:string; children:React.ReactNode; onClose:()=>void }) { return <div className="modal-backdrop"><aside className="drawer"><div className="modal-head"><h3>{title}</h3><button onClick={onClose}><X/></button></div>{children}</aside></div> }
function DataTable({ headers, rows }: { headers:string[]; rows:React.ReactNode[][] }) { return <Table headers={headers}>{rows.map((row, i) => <tr key={i}>{row.map((cell,j) => <td key={j}>{cell}</td>)}</tr>)}</Table> }

const loadmenTotals={Surender:16500,Nithish:13500,Kulla:14500,Rahul:15500,Vimal:9000,Murugan:10500,Selvam:8000,Ravi:6500}
function TripLedger(){const [q,setQ]=useState('');const [s,setS]=useState('All');const rows=trips.filter(t=>(s==='All'||t.status===s)&&`${t.id} ${t.vehicle} ${t.material} ${t.supplier}`.toLowerCase().includes(q.toLowerCase()));const total=rows.reduce((a,t)=>{const x=saleTotals(t.kg,t.rate);return{kg:a.kg+t.kg,before:a.before+x.beforeTax,bill:a.bill+x.grandTotal,tds:a.tds+x.tds}}, {kg:0,before:0,bill:0,tds:0});return <section className="content"><div className="hero-row"><div><h2>Trip ledger</h2><p>Sales, purchases and margin by trip. Incomplete trips remain visible.</p></div><button className="primary-btn" onClick={()=>alert('Trip form ready')}><Plus/>Add trip</button></div><div className="stat-grid four"><Stat label="Trips" value={String(rows.length)}/><Stat label="Total weight" value={`${formatKg(total.kg)} kg`}/><Stat label="Sales before tax" value={money(total.before)}/><Stat label="Incomplete" value={String(rows.filter(t=>t.status==='Incomplete').length)} highlight/></div><div className="toolbar"><input placeholder="Search trip, vehicle or material" value={q} onChange={e=>setQ(e.target.value)}/><select value={s} onChange={e=>setS(e.target.value)}><option>All</option><option>Complete</option><option>Incomplete</option></select></div><Table headers={['Trip','Date','Vehicle','Material','Weight','Rate','Before tax','2% TDS','Bill amount','Supplier','Driver','Status']}><tr className="totals-row"><td>Total</td><td>—</td><td>—</td><td>—</td><td>{formatKg(total.kg)}</td><td>—</td><td>{money(total.before)}</td><td>{money(total.tds)}</td><td>{money(total.bill)}</td><td colSpan={3}>—</td></tr>{rows.map(t=>{const x=saleTotals(t.kg,t.rate);return <tr key={t.id}><td><b>{t.id}</b></td><td>{formatDate(t.date)}</td><td>{t.vehicle}</td><td>{t.material}</td><td className="numeric">{formatKg(t.kg)}</td><td className="numeric">{money(t.rate)}</td><td className="numeric">{money(x.beforeTax)}</td><td className="numeric">{money(x.tds)}</td><td className="numeric">{money(x.grandTotal)}</td><td>{t.supplier}</td><td>{t.driver||'—'}</td><td><Badge status={t.status}/></td></tr>})}</Table></section>}
function LoadmenLog(){const total=Object.values(loadmenTotals).reduce((a,b)=>a+b,0);return <section className="content"><div className="hero-row"><div><h2>Loadmen log</h2><p>Daily loading and unloading payments for May 2026.</p></div><button className="primary-btn" onClick={()=>alert('Loadmen payment form ready')}><Plus/>Add payment</button></div><div className="stat-grid three"><Stat label="Payments logged" value="77"/><Stat label="Total paid to loadmen" value={money(total)}/><Stat label="Workers paid" value="8"/></div><Table headers={['Name','Days worked','Payments','Total paid']}><tr className="totals-row"><td>Total</td><td>—</td><td>77</td><td>{money(total)}</td></tr>{Object.entries(loadmenTotals).map(([name,value])=><tr key={name}><td>{name}</td><td>{Math.max(1,Math.round(value/1200))}</td><td>—</td><td className="numeric">{money(value)}</td></tr>)}</Table></section>}
function Expenses(){const diesel=trips.reduce((a,t)=>a+Math.max(1200,Math.round(t.kg*.2/50)*50)*2,0),loadmen=94000,wages=46500,other=17200,total=diesel+loadmen+wages+other;return <section className="content"><div className="hero-row"><div><h2>Expenses</h2><p>Operating expenses for May 2026.</p></div><button className="primary-btn" onClick={()=>alert('Expense form ready')}><Plus/>Add expense</button></div><div className="stat-grid five"><Stat label="Total expenses" value={money(total)}/><Stat label="Daily wages" value={money(wages)}/><Stat label="Diesel" value={money(diesel)}/><Stat label="Loadmen" value={money(loadmen)}/><Stat label="Other" value={money(other)}/></div><p className="caption">Wages are charged every day, whether or not a trip happens.</p><Table headers={['Month','Days','Driver wages','Supervisor wages','Total']}><tr><td>May 2026</td><td>31</td><td>{money(24800)}</td><td>{money(21700)}</td><td className="numeric">{money(wages)}</td></tr><tr><td>April 2026</td><td>30</td><td>{money(24000)}</td><td>{money(21000)}</td><td className="numeric">{money(45000)}</td></tr><tr className="totals-row"><td>Total</td><td>61</td><td>—</td><td>—</td><td>{money(wages+45000)}</td></tr></Table></section>}

function Overview({ pending, notify }: { pending:number; notify:(message:string)=>void }) {
  const soldKg = trips.reduce((sum, trip) => sum + trip.kg, 0)
  const purchasedKg = trips.reduce((sum, trip) => sum + (trip.purchaseKg || 0), 0)
  const sales = trips.reduce((sum, trip) => sum + saleTotals(trip.kg, trip.rate).grandTotal, 0)
  const purchase = trips.reduce((sum, trip) => sum + purchaseAmount(trip.purchaseKg || 0, trip.purchaseRate || 0), 0)
  const complete = trips.filter((trip) => trip.status === 'Complete').length
  const trend = trips.slice(-6).map((trip) => saleTotals(trip.kg, trip.rate).grandTotal)
  const maxTrend = Math.max(...trend)

  return <section className="content overview-content">
    <div className="overview-welcome">
      <div><span className="eyebrow">MAY 2026 · ACCOUNTING SUMMARY</span><h2>Good morning, Accounts</h2><p>Here&apos;s a clear view of your steel trading activity, cash position and latest trips.</p></div>
      <button className="primary-btn" onClick={() => notify('Ready to record a new entry')}><Plus/>Add entry</button>
    </div>
    <div className="overview-kpis">
      <div className="overview-kpi overview-kpi-primary"><span>Sales before tax</span><strong>{money(sales)}</strong><small>{formatKg(soldKg)} kg sold across {trips.length} trips</small></div>
      <div className="overview-kpi"><span>Purchase cost</span><strong>{money(purchase)}</strong><small>{formatKg(purchasedKg)} kg purchased</small></div>
      <div className="overview-kpi"><span>Loadmen paid</span><strong>{money(94000)}</strong><small>77 payment entries logged</small></div>
      <div className="overview-kpi overview-kpi-alert"><span>Receivables pending</span><strong>{money(pending)}</strong><small>Net amount still due from customer</small></div>
    </div>
    <div className="overview-panels">
      <div className="overview-panel overview-trend"><div className="overview-panel-head"><div><h3>Sales trend</h3><p>Bill value by latest trip</p></div><span className="overview-pill">{complete} complete</span></div><div className="overview-bars">{trend.map((value, index) => <div className="overview-bar-item" key={trips[index + trips.length - trend.length].id}><div className="overview-bar-value">{money(value)}</div><div className="overview-bar" style={{height:`${Math.max(22, value / maxTrend * 118)}px`}}/><small>{trips[index + trips.length - trend.length].id.replace('TR-','')}</small></div>)}</div></div>
      <div className="overview-panel overview-health"><div className="overview-panel-head"><div><h3>Business health</h3><p>Current operating snapshot</p></div></div><div className="health-row"><span>Trips completed</span><strong>{complete} / {trips.length}</strong><div className="health-track"><i style={{width:`${complete / trips.length * 100}%`}}/></div></div><div className="health-row"><span>Credit available</span><strong>{money(7500000 - pending)}</strong><div className="health-track"><i className="health-blue" style={{width:`${Math.max(8, (7500000 - pending) / 7500000 * 100)}%`}}/></div></div><div className="overview-attention"><strong>Needs attention</strong><span>Payable to suppliers {money(640516)}</span><span>{trips.length - complete} trips still incomplete</span></div></div>
    </div>
    <div className="overview-panel overview-recent"><div className="overview-panel-head"><div><h3>Latest trips</h3><p>Recent activity across your ledger</p></div><button className="text-btn" onClick={() => notify('Open Trip ledger from the sidebar')}>View trip ledger</button></div><DataTable headers={['Trip','Date','Material','Weight','Bill amount']} rows={trips.slice(-6).reverse().map((trip) => [trip.id, formatDate(trip.date), trip.material, `${formatKg(trip.kg)} kg`, money(saleTotals(trip.kg, trip.rate).grandTotal)])}/></div>
  </section>
}

export default function Page() {
  const [active, setActive] = useState('Overview'); const [mobile, setMobile] = useState(false); const [toast, setToast] = useState(''); const [pending, setPending] = useState(1018639.95); const [session, setSession] = useState<{ role:string; displayName:string; title:string } | null>(null)
  useEffect(() => {
    const raw = window.localStorage.getItem(SESSION_KEY)
    if (!raw) { window.location.replace('/login'); return }
    try {
      const parsed = JSON.parse(raw)
      if (!canAccessRoute(parsed.role, window.location.pathname)) { window.location.replace(getHomePath(parsed.role)); return }
      setSession(parsed)
    } catch { window.localStorage.removeItem(SESSION_KEY); window.location.replace('/login') }
  }, [])
  const notify = (message:string) => { setToast(message); window.setTimeout(() => setToast(''), 2400) }
  const nav = [['Overview',LayoutDashboard],['Trip ledger',ClipboardList],['Loadmen log',Users],['Expenses',WalletCards],['Payments & credit',ReceiptIndianRupee]] as const
  const overviewRows = trips.slice(-6).map((trip) => [trip.id, formatDate(trip.date), trip.material, `${formatKg(trip.kg)} kg`, money(saleTotals(trip.kg, trip.rate).grandTotal)])
  if (!session) return null
  return <WorkspaceShell workspace="Accounting" navItems={nav.map(([label, icon]) => ({ label, href: '#', icon }))} user={{ name: session.displayName || 'Accounts', role: session.title || 'Administrator', initials: 'AK' }} breadcrumb={`ACCOUNTING / ${active.toUpperCase()}`} title={active} legacy><div className="app-shell"><aside className={`sidebar ${mobile ? 'open' : ''}`}><div className="brand"><div className="brand-mark" aria-label="JZ logo">JZ</div><div><b>JAZLAN</b><span>STEELS</span></div><button className="close-mobile" onClick={() => setMobile(false)}><X/></button></div><div className="workspace-label"><span>ACCOUNTING WORKSPACE</span></div><nav>{nav.map(([label, Icon]) => <button key={label} className={active === label ? 'active' : ''} onClick={() => { setActive(label); setMobile(false) }}><Icon/>{label}</button>)}</nav><div className="sidebar-bottom"><button><Settings/>Settings</button><div className="user-chip"><div><b>{session?.displayName || 'Accounts'}</b><span>{session?.title || 'Administrator'}</span></div></div><button className="logout" onClick={() => { window.localStorage.removeItem(SESSION_KEY); window.location.replace('/login') }}>Sign out</button></div></aside><main className="main-content"><header className="topbar"><button className="menu-btn" onClick={() => setMobile(true)}><Menu/></button><div><p className="eyebrow">ACCOUNTING / {active.toUpperCase()}</p><h1>{active}</h1><p className="workspace-subtitle">Here&apos;s what&apos;s happening with your business today.</p></div><div className="top-actions"><span>Period · This month</span><Bell/><div className="top-avatar">AK</div></div></header>{active === 'Payments & credit' ? <Payments notify={notify} setPending={setPending}/> : active === 'Trip ledger' ? <TripLedger/> : active === 'Loadmen log' ? <LoadmenLog/> : active === 'Expenses' ? <Expenses/> : active === 'Overview' ? <Overview pending={pending} notify={notify}/> : <section className="content"><div className="hero-row"><div><h2>{active}</h2><p>Here&apos;s what&apos;s happening with your business today.</p></div><button className="primary-btn" onClick={() => notify('Ready to record a new entry')}><Plus/>Add entry</button></div><div className="stat-grid three"><Stat label="Sales before tax" value={money(6280082)}/><Stat label="Purchase cost" value={money(4240516)}/><Stat label="Loadmen paid" value={money(94000)}/></div>{active === 'Overview' && <><div className="attention"><strong>Needs attention</strong><span>Pending receivables {money(pending)}</span><span>Payable to suppliers {money(640516)}</span></div><DataTable headers={['Trip','Date','Material','Quantity','Billed total']} rows={overviewRows}/></>}</section>}</main>{toast && <div className="toast">{toast}</div>}</div></WorkspaceShell>
}
