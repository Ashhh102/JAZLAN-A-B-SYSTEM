'use client'

import { FormEvent, useEffect, useState } from 'react'
import { Eye, EyeOff, LockKeyhole, UserRound } from 'lucide-react'
import { authenticate, getHomePath, SESSION_KEY } from '@/lib/auth'

export default function LoginPage() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    const session = window.localStorage.getItem(SESSION_KEY)
    if (session) {
      try { window.location.replace(getHomePath(JSON.parse(session).role)) } catch { window.localStorage.removeItem(SESSION_KEY) }
    }
  }, [])

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const user = authenticate(username, password)
    if (!user) { setError('Incorrect username or password'); return }
    window.localStorage.setItem(SESSION_KEY, JSON.stringify({ username: user.username, role: user.role, displayName: user.displayName, title: user.title }))
    window.location.assign(getHomePath(user.role))
  }

  return <main className="login-page">
    <section className="login-brand-panel">
      <div className="login-brand-mark">JZ</div>
      <div><p className="login-kicker">JAZLAN</p><h1>STEELS</h1><p className="login-tagline">Billing and Accounting System</p></div>
      <div className="login-brand-footer"><span>JAZLAN STEELS</span><span>ACCOUNTING WORKSPACE</span></div>
    </section>
    <section className="login-form-panel">
      <div className="login-card">
        <div className="login-card-heading"><div className="login-lock"><LockKeyhole /></div><span className="eyebrow">SECURE ACCESS</span><h2>Welcome back</h2><p>Sign in to continue to your workspace.</p></div>
        <form onSubmit={submit}>
          <label>Username<div className="login-input"><UserRound /><input value={username} onChange={(event) => { setUsername(event.target.value); setError('') }} autoComplete="username" placeholder="Enter username" /></div></label>
          <label>Password<div className="login-input"><LockKeyhole /><input type={showPassword ? 'text' : 'password'} value={password} onChange={(event) => { setPassword(event.target.value); setError('') }} autoComplete="current-password" placeholder="Enter password" /><button type="button" aria-label={showPassword ? 'Hide password' : 'Show password'} onClick={() => setShowPassword((value) => !value)}>{showPassword ? <EyeOff /> : <Eye />}</button></div></label>
          <div className="login-error" aria-live="polite">{error}</div>
          <button className="login-submit" type="submit">Sign in</button>
        </form>
        <div className="demo-accounts"><strong>Demo accounts</strong><span><b>accounts</b> / demo123 <em>Accounting</em></span><span><b>billing</b> / demo123 <em>Billing</em></span></div>
      </div>
    </section>
  </main>
}
